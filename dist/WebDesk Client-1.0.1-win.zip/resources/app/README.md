# webdesk-client
Desktop application for connecting to a web server
